<?php
/**
 * Hostinger production database — do not commit (see .gitignore).
 * For local XAMPP dev: rename or remove this file so defaults in database.php apply.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'u621000858_appgrade');
define('DB_USER', 'u621000858_appgrade');
define('DB_PASS', 'Appgrade2026');
define('DB_CHARSET', 'utf8mb4');
